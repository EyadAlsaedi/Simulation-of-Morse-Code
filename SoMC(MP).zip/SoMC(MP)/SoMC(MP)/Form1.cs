﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SoMC_MP_
{
    public partial class Form1 : Form
    {
         bool mousedown;

        public Form1()
        {
            InitializeComponent();
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            textBox1.Text = textBox1.Text.ToUpper();
            string[] alphabet = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            string[] morse = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----.", "-----" };

            for (int i = 0; i < textBox1.Text.Length; i++)
            {
                for (int j = 0; j < alphabet.Length; j++)
                {
                    if (textBox1.Text[i].ToString() == alphabet[j])
                    {
                        textBox2.Text += morse[j] + " ";
                        break;
                    }
                }
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text = null; 
            textBox2.Text= null;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text= null;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox2.Text = null;
        }

        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {

        }

        private void panel2_MouseDown(object sender, MouseEventArgs e)
        {
            mousedown = true;
        }

        private void panel2_MouseMove(object sender, MouseEventArgs e)
        {
            if (mousedown) {
                int mousex = MousePosition.X - 400;
                int mousey = MousePosition.Y - 20;
                this.SetDesktopLocation(mousex, mousey);

            }
        }

        private void panel2_MouseUp(object sender, MouseEventArgs e)
        {
            mousedown= false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            string[] alphabet = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            string[] morse = { ".-", "-...", "-.-.", "-..", ".", "..-.", "--.", "....", "..", ".---", "-.-", ".-..", "--", "-.", "---", ".--.", "--.-", ".-.", "...", "-", "..-", "...-", ".--", "-..-", "-.--", "--..", ".----", "..---", "...--", "....-", ".....", "-....", "--...", "---..", "----.", "-----" };
            string[] words = textBox2.Text.Split(' ');


            foreach (string word in words)
            {
                for (int i = 0; i < morse.Length; i++)
                {
                    if (word == morse[i])
                    {
                        textBox1.Text += alphabet[i];
                        break;
                    }
                }
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            

        }
    }
}
